window.ASSET_PREFIX = "";
window.SCRIPT_PREFIX = "";
window.SCENE_PATH = "1898802.json";
window.CONTEXT_OPTIONS = {
    'antialias': true,
    'alpha': false,
    'preserveDrawingBuffer': false,
    'preferWebGl2': true,
    'powerPreference': "high-performance"
};
window.SCRIPTS = [ 157091651, 157031701, 157032492, 157032473, 157032474, 157032476, 157032477, 157032478, 157032479, 157032480, 157032481, 157032482, 157032483, 157032484 ];
window.CONFIG_FILENAME = "config.json";
window.INPUT_SETTINGS = {
    useKeyboard: true,
    useMouse: true,
    useGamepads: false,
    useTouch: true
};
pc.script.legacy = false;
window.PRELOAD_MODULES = [
    {'moduleName' : 'Ammo', 'glueUrl' : 'files/assets/157036446/1/ammo.wasm.js', 'wasmUrl' : 'files/assets/157036447/1/ammo.wasm.wasm', 'fallbackUrl' : 'files/assets/157036445/1/ammo.js', 'preload' : true},
];
